package com.Try1;

import java.sql.Date;

import javax.jdo.annotations.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_try1")
public class Bikemaint
{
	@Id
	@Column(name="bikemaint_id")
	private int bikemaint_id;
	
	@Column(name="bikeid")
	private int bikeid;
	
	
	@Column(name="start_date")
	private Date start_date;
	
	@Column(name="end_date")
	private Date end_date;
	
	
	@Column(name="condition1")
	private String condition1;
	
	
	public int getBikemaint_id() {
		return bikemaint_id;
	}

	public void setBikemaint_id(int bikemaint_id) {
		this.bikemaint_id = bikemaint_id;
	}

	public int getBikeid() {
		return bikeid;
	}

	public void setBike_id(int bikeid) {
		this.bikeid = bikeid;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public Date getEnd_date() {
		return end_date;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}

	public String getCondition() {
		return condition1;
	}

	public void setCondition(String condition) {
		this.condition1 = condition;
	}

	@Override
	public String toString() {
		return "Bikemaint {bikemaint_id=" + bikemaint_id + ", bikeid=" + bikeid + ", start_date=" + start_date
				+ ", end_date=" + end_date + ", condition=" + condition1 + "}";
	}


	


	
}
