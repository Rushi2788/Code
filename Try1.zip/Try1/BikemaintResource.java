package com.Try1;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Try.BikeService;
import com.generated.web.rest.util.PaginationUtil;

import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/api")
public class BikemaintResource
{
@PersistenceContext
EntityManager entityManager;
	
@Autowired
BikemaintService bikemaintservice;
	
//@Qualifier(value ="BikeServiceImpl")////////////////////////////////////////

BikeService bikeservice;//////////////////////////////////////////////////////////////////////////////////////////////////////////////trigger option////////////////////////////////////////////////////////

/////////////Create entry/
@PostMapping("/bikemaint")
public String createBikemaint(@RequestBody Bikemaint bikemaint) {

	Bikemaint b=findById(bikemaint.getBikemaint_id());
	
	System.out.println("--------------------------------------------------------------------"+bikemaint);
	
	if(b==null)
	{
		System.out.println("fdfdjdssfdfhjd -----------------------------------");
		bikemaintservice.createBikemaint(bikemaint);
		
		
		
		System.out.println("oky");
		/////////////rushi change
		bikeservice.updateStuas(bikemaint.getBikeid(),"Under Maintain");///////////////////////////////////////////////////////////////////////////////trigger option///////////////////////////////////////
		
		
		return "Created";
	}
	
	else {
		updateBikemaint(bikemaint);
		return "Update";
		
			}
	
	
}
/////////////////////////////////update
public String updateBikemaint(@RequestBody Bikemaint bikemaint)
{
	bikemaintservice.update(bikemaint);
	
	/////////////rushi change
	bikeservice.updateStuas(bikemaint.getBikeid(),"Under Maintain");
	
	
	return "update";
	
}






////////////////////////////delete
@DeleteMapping("/bikemaint/{bikeid}")
public void deleteById(@PathVariable("bikeid") int id)
{
	
Bikemaint bikemaint=bikemaintservice.findById(id);

//bikeservice.updateStuas(bike.getBike_id,"Not Under Maintenance");//////////////////////////////////////////////////////


bikemaintservice.deleteId(id);
}









///////////////////////get by id
@GetMapping("/bikemaint/{bikeid}")
public Bikemaint findById(@PathVariable("bikeid") int id)
{
	return bikemaintservice.findById(id);
}





//////////////////get all

@GetMapping("/bikemaint")
public ResponseEntity<List<Bikemaint>>getAll(@ApiParam Pageable pageable)
{
	 Iterable<Bikemaint> data=bikemaintservice.getAll();
     List<Bikemaint> list = new ArrayList<Bikemaint>();
   
      System.out.println("Test Service :");
    
      for(Bikemaint s: data){
         System.out.println(s);
         list.add(s);
      }

      Page<Bikemaint> page = new PageImpl<Bikemaint>(list, pageable, list.size());
 		HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/bikemaint");
	          return new ResponseEntity<>(list, headers, HttpStatus.OK);
	          
	}
	







}
