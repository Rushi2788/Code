package com.Try1;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;


public class SendSms {
	
	public static void SendSMS()
	{
		Twilio.init("AC28622cb48724654f947126945566f2bc", "3696f1a19403cdaf2a284e44d846ee99");//Tokan & SID
        Message message = Message.creator(
                new PhoneNumber("+91880601245"),////first u have to register with Twilo then ferther process on!
                new PhoneNumber("+1201932103688888"),
                "Hi Bike Go to Maintance Mode")
            .create();

        System.out.println(message.getSid());
    }


}
