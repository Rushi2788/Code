package com.Try1;

import org.springframework.data.jpa.repository.JpaRepository;


public interface BikemaintRepository extends JpaRepository<Bikemaint, Integer> {


}
