package com.Try1;

public interface BikemaintService {

	void createBikemaint(Bikemaint bikemaint);

	void update(Bikemaint bikemaint);



	Iterable<Bikemaint> getAll();

	Bikemaint findById(int id);

	void deleteId(int id);






}
