package com.Try3;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import com.codahale.metrics.annotation.Timed;

import io.swagger.annotations.ApiParam;

public class ctr {

	@Autowired
	fileService fileService;
	
	
	@GetMapping("/filereader")
	@Timed
public ResponseEntity<List<History>> getAllHistory(@ApiParam Pageable pageable){
	  // log.debug("REST request to get a page of wards");
	   History history=new History();
	   
	   ArrayList<History> listhistory=new ArrayList<History>();
	   
	   String data =new String();
	   int count=0;
	   try
       {
		  // Runtime.getRuntime().exec("attrib -H JavaBooks.xlsx");
           FileInputStream file = new FileInputStream(new File("JavaBooks.xlsx"));

           //Create Workbook instance holding reference to .xlsx file
           XSSFWorkbook workbook = new XSSFWorkbook(file);

           //Get first/desired sheet from the workbook
           XSSFSheet sheet = workbook.getSheetAt(0);

           //Iterate through each rows one by one
           Iterator<Row> rowIterator = sheet.iterator();
           while (rowIterator.hasNext())
           {
        	   
        	   
               Row row = rowIterator.next();
               //For each row, iterate through all the columns
               Iterator<Cell> cellIterator = row.cellIterator();
              
               
               // ------------------------
               if(count !=0 || count !=1)
            	   listhistory.add(   new History(row.getCell(0).toString(), row.getCell(1).toString(), row.getCell(2).toString()));
            		//  new History(sName, address, nFlat, wreq, oopration, date)
        
            		   System.out.println(listhistory);
            		  // row.getCell(1).toString();
               
               while (cellIterator.hasNext())
               {
                   Cell cell = cellIterator.next();
                   //Check the cell type and format accordingly	
                   switch (cell.getCellType())
                   {
                       case Cell.CELL_TYPE_NUMERIC:
               //            System.out.print(cell.getNumericCellValue() + "  ");
                           if(count !=0 || count !=1)
                           data+=cell.getNumericCellValue()+" ";
                           break;
                       case Cell.CELL_TYPE_STRING:
             //              System.out.print(cell.getStringCellValue() + "  ");
                           if(count !=0 || count !=1)
                           data+=cell.getStringCellValue()+" ";
                           break;
                   }
               }
               System.out.println("");
               data+="\n";
               count++;
           }
           
           Runtime.getRuntime().exec("attrib +h JavaBooks.xlsx");
           file.close();
           
           //attrib +h "Secret Files"
           
           //System.out.println("----------------------------------------");
           //System.out.println(data);
           
           
       }
       catch (Exception e)
       {
           e.printStackTrace();
       }
	   
	   
    System.out.println("Testing : --------------");
	  List<History> page = listhistory;
	  
    System.out.println("Testing : --------------");
	   
   // List<WS_Society> list = WS_SocietyService.findAll(pageable); 
	   
     //Page<WS_Society> page = new PageImpl<WS_Society>(list, pageable, list.size());
     //HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/WS_Society");
     return new ResponseEntity<>(page,  HttpStatus.OK);
 }

}
