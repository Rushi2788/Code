package com.Try3;


import java.io.*;
import java.util.Scanner;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook; 
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet; 
import org.apache.poi.ss.usermodel.Workbook;


public class test{
	public static void main(String[]args) {

		try {
			Scanner sc = new Scanner(System.in); 
			String filename = "D:/NewExcelFile.xls";
			HSSFWorkbook workbook = new HSSFWorkbook();
			HSSFSheet sheet =   workbook.createSheet("FirstSheet");
			HSSFRow rowhead = sheet.createRow((short)0);

			rowhead.createCell(0).setCellValue("No.");
			rowhead.createCell(1).setCellValue("Name");
			rowhead.createCell(2).setCellValue("Address");
			rowhead.createCell(3).setCellValue("Email");
			
			while(true) {
				int no;
				String name;
				String Country;
				String gmail;
				
				int lastRow=sheet.getLastRowNum();
				System.out.println(lastRow);
				Row row = sheet.createRow(++lastRow); 
				System.out.println("----------------------------TEST---------------------------");


				System.out.println("enter number"); 
				row.createCell(0).setCellValue (no =sc.nextInt());

				sc.nextLine(); 


				System.out.println("enter name");
				row.createCell(1).setCellValue (name =  sc.nextLine());
				Row nextRow = sheet.getRow(row.getRowNum() + 1);


				System.out.println("Enter Country");
				row.createCell(2).setCellValue(Country =sc.nextLine());



				System.out.println("Enter Gmail");
				row.createCell(3).setCellValue(gmail = sc.nextLine());
				//	row.createCell(3).setCellValue(System.getProperty("line.separator"));

				FileOutputStream fileOut = new FileOutputStream(filename);
				workbook.write(fileOut); 
				fileOut.close();

				System.out.println("Your excel file has been generated!");
				System.out.println("Next entry Number  " + (no+1));

			}
		}
		catch ( Exception ex ) { System.out.println(ex); }



	} }