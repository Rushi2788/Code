package com.Try3;

import com.lab.Try.Bike;

public interface fileService 
{
	public void addHistory(History history);
}
