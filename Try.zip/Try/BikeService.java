package com.Try;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

@Service
@Transactional

public interface BikeService {
	public void createBike(Bike bike);
	public void update(Bike bike);
	public Bike findId(int id);
	public void deleteId(int id);
	public Iterable<Bike> getAll();
	public void updateStuas(int bikeid, String string); ///////////////////////////////////////////////////////////////////////////////Trigger Option///////////////////////////////////
	   public List<Bike> getAssetAuditData();
	   public List<Bike> getRushi();
	//public void addHistory(History history);
}
