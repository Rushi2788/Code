package com.Try;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codahale.metrics.annotation.Timed;


import com.generated.web.rest.util.PaginationUtil;

import io.swagger.annotations.ApiParam;


@RestController
@PreAuthorize("isFullyAuthenticated()")
@CrossOrigin(origins = "*")

@RequestMapping("/api/v1")
public class BikeResource
{

	@PersistenceContext
	EntityManager entityManager;
	
	@Autowired
	BikeService bikeservice;
	
	
////////Creat New Entry//////////
	@PostMapping("/bikecreated")
	@Timed
	public String createBike(@RequestBody Bike bike) 
	{
		
		Bike b=findById(bike.getBikeid());
		if(b==null)
		{
			
			bikeservice.createBike(bike);
			
						
			return "Cretaed";
		}
		else {
			
			updateBike(bike);
			return "updated";
		}		
		
		
	}

//update
	@PutMapping("/bikeupdated")
	public String updateBike(@RequestBody Bike bike)
	{
		bikeservice.update(bike);
		return "update";
	}
	
	//delete
	
	@DeleteMapping("bikedeleted/{bikeid}")
	public void deleteById(@PathVariable("bikeid")int id)
	{
		Bike bike=bikeservice.findId(id);
		bikeservice.deleteId(id);
	}
	
	//////////////get by id
	
	@GetMapping("/bikebyid/{bikeid}")
	public Bike findById(@PathVariable("bikeid")int id)
	{	
		return bikeservice.findId(id);
	}
	
	
		
	////////////////////PDF///////////////////////////////////////////////////////////////////////////////
	
	@GetMapping("/pdf")
	public ResponseEntity<ByteArrayResource>getPdf(@ApiParam Pageable pageable)
	{
		 Iterable<Bike> data=bikeservice.getAll();
         List<Bike> list = new ArrayList<Bike>();
       
          System.out.println("Test Service :");
        
          for(Bike s: data){
             System.out.println(s);
             list.add(s);
          }
             List<Bike> page = list;
             ByteArrayResource bis=GeneratePdfReport.bikeReport(page);
   		   		return ResponseEntity
   	            .ok()
   	            .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=SocietyReport.pdf")
   	            .contentType(MediaType.APPLICATION_PDF)
   	            .body(bis);
	          
	}
////////////////get all//////////////////////////////////
	
@GetMapping("/bikegetall") 
public ResponseEntity<List<Bike>>getAll(@ApiParam Pageable pageable)
{ 
	Iterable<Bike> data=bikeservice.getAll();
	List<Bike>list = new ArrayList<Bike>();

System.out.println("Test Service :");

for(Bike s: data)
{
	System.out.println(s); 
	list.add(s);
}
Page<Bike> page =new PageImpl<Bike>(list, pageable, list.size()); 
	HttpHeaders headers =PaginationUtil.generatePaginationHttpHeaders(page, "/api/bike"); 
	return new ResponseEntity<>(list, headers, HttpStatus.OK);

}
	
/////////////////////////////////////Custom Query////////////////////for first  3 elememt///////////////////////////////////////////////////
	 
@GetMapping("/3")
public ResponseEntity<List<Bike>>getAssetAuditData(@ApiParam Pageable pageable) 
{
Iterable<Bike> data=bikeservice.getAssetAuditData(); List<Bike>
list = new ArrayList<Bike>();

System.out.println("Test Service :");

for(Bike s: data){ System.out.println(s); list.add(s); } Page<Bike> page =
new PageImpl<Bike>(list, pageable, list.size()); HttpHeaders headers =
PaginationUtil.generatePaginationHttpHeaders(page, "/api/bike"); return new
ResponseEntity<>(list, headers, HttpStatus.OK);

}
	
/////////////////////////////////////Custom Query////////////////////for first  1 elememt///////////////////////////////////////////////////


@GetMapping("/1")
public ResponseEntity<List<Bike>>getRushi(@ApiParam Pageable pageable) 
{
Iterable<Bike> data=bikeservice.getRushi();
List<Bike> list = new ArrayList<Bike>();

System.out.println("Test Service :");

for(Bike s: data){ System.out.println(s); list.add(s); } Page<Bike> page =
new PageImpl<Bike>(list, pageable, list.size()); HttpHeaders headers =
PaginationUtil.generatePaginationHttpHeaders(page, "/api/bike"); return new
ResponseEntity<>(list, headers, HttpStatus.OK);

}
	/*
	 * @GetMapping("/ExcelToDB") public ResponseEntity<List<History>>
	 * getAllHistory(@ApiParam Pageable pageable){ //
	 * log.debug("REST request to get a page of wards"); History history=new
	 * History();
	 * 
	 * ArrayList<History> listhistory=new ArrayList<History>();
	 * 
	 * String data =new String(); int count=0; try {
	 * //Runtime.getRuntime().exec("attrib -H JavaBooks.xlsx"); FileInputStream file
	 * = new FileInputStream(new File("D:\\abc.xlsx"));
	 * 
	 * //Create Workbook instance holding reference to .xlsx file XSSFWorkbook
	 * workbook = new XSSFWorkbook(file);
	 * 
	 * //Get first/desired sheet from the workbook XSSFSheet sheet =
	 * workbook.getSheetAt(0);
	 * 
	 * //Iterate through each rows one by one Iterator<Row> rowIterator =
	 * sheet.iterator(); while (rowIterator.hasNext()) {
	 * 
	 * 
	 * Row row = rowIterator.next(); //For each row, iterate through all the columns
	 * Iterator<Cell> cellIterator = row.cellIterator();
	 * 
	 * 
	 * // ------------------------ if(count !=0 || count !=1)
	 * 
	 * listhistory.add( new History(row.getCell(0).toString(),
	 * row.getCell(1).toString(), row.getCell(2).toString()));
	 * 
	 * // bikeservice.addHistory(history);
	 * 
	 * // new History(sName, address, nFlat, wreq, oopration, date)
	 * 
	 * System.out.println(listhistory); // row.getCell(1).toString();
	 * 
	 * while (cellIterator.hasNext()) { Cell cell = cellIterator.next(); //Check the
	 * cell type and format accordingly switch (cell.getCellType()) { case
	 * Cell.CELL_TYPE_NUMERIC: // System.out.print(cell.getNumericCellValue() +
	 * "  "); if(count !=0 || count !=1) data+=cell.getNumericCellValue()+" ";
	 * break; case Cell.CELL_TYPE_STRING: //
	 * System.out.print(cell.getStringCellValue() + "  "); if(count !=0 || count
	 * !=1) data+=cell.getStringCellValue()+" "; break; } } System.out.println("");
	 * data+="\n"; count++; }
	 * 
	 * //Runtime.getRuntime().exec("attrib +h JavaBooks.xlsx"); file.close();
	 * 
	 * //attrib +h "Secret Files"
	 * 
	 * //System.out.println("----------------------------------------");
	 * //System.out.println(data);
	 * 
	 * 
	 * } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * 
	 * System.out.println("Testing : --------------"); List<History> page =
	 * listhistory;
	 * 
	 * System.out.println("Testing : --------------");
	 * 
	 * // List<WS_Society> list = WS_SocietyService.findAll(pageable);
	 * 
	 * //Page<WS_Society> page = new PageImpl<WS_Society>(list, pageable,
	 * list.size()); //HttpHeaders headers =
	 * PaginationUtil.generatePaginationHttpHeaders(page, "/api/WS_Society"); return
	 * new ResponseEntity<>(page, HttpStatus.OK); }
	 */
}
