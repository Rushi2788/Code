package com.Try;

import javax.jdo.annotations.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="filereader")
public class History {
	@Column(name="krishna")
	String krishna;
	@Column(name="rushi")
	String rushi;
	@Column(name="bro")
	String bro;
	
public History() {
	// TODO Auto-generated constructor stub
}

	@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((bro == null) ? 0 : bro.hashCode());
	result = prime * result + ((krishna == null) ? 0 : krishna.hashCode());
	result = prime * result + ((rushi == null) ? 0 : rushi.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	History other = (History) obj;
	if (bro == null) {
		if (other.bro != null)
			return false;
	} else if (!bro.equals(other.bro))
		return false;
	if (krishna == null) {
		if (other.krishna != null)
			return false;
	} else if (!krishna.equals(other.krishna))
		return false;
	if (rushi == null) {
		if (other.rushi != null)
			return false;
	} else if (!rushi.equals(other.rushi))
		return false;
	return true;
}

	public History(String krishna, String rushi, String bro) {
	super();
	this.krishna = krishna;
	this.rushi = rushi;
	this.bro = bro;
}

	public String getKrishna() {
		return krishna;
	}
	public void setKrishna(String krishna) {
		this.krishna = krishna;
	}
	public String getRushi() {
		return rushi;
	}
	public void setRushi(String rushi) {
		this.rushi = rushi;
	}
	public String getBro() {
		return bro;
	}
	public void setBro(String bro) {
		this.bro = bro;
	}






	
}
