package com.Try;

import javax.jdo.annotations.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
@Entity
@Table(name="tbl_try")
public class Bike {

	@Id
	@NotNull
	@Column(name="bikeid")
	 int bikeid;
	
	@Column(name="bikename")
	private String bikename;
	
	@Column(name="remark")
	private String remark;
	
	


	
	public int getBikeid() {
		return bikeid;
	}

	public void setBikeid(int bikeid) {
		this.bikeid = bikeid;
	}

	public String getBikename() {
		return bikename;
	}

	public void setBikename(String bikename) {
		this.bikename = bikename;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	


	
	
	
	
	
	

}
