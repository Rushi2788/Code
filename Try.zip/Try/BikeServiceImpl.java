package com.Try;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.Try1.BikemaintServiceImpl;


//@Configuration
//@EnableScheduling
@Service
@Transactional
public class BikeServiceImpl implements BikeService {


	@Autowired
	BikeRepository repo;

	@Autowired
	BikemaintServiceImpl A;
	
	@Autowired
	HistoryRepository hrepo;


	@Override
	public void createBike(Bike bike) {

		repo.save(bike);
		

		//////////////////////////////////////
		String un=A.username;
		String pw=A.password;
		String to=A.to;
		String smtp=A.smtp;   
///////////////////////////////////////////////////////////////////////////////////////////////////////////bike  Created Mail Code///////////////////////////
//		try {
//
//			A.sendPlainTextEmail(smtp, "587", un, pw, to, "Bike", "Bro");
//
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}	   
//////////////////////////////////////

	}


	@Override
	public void update(Bike bike) {
		repo.save(bike);		



	}

	@Override
	public Bike findId(int id) {
		return repo.findOne(id);
	}

	@Override
	public void deleteId(int id) {
		repo.delete(id);		
	}




	@Override
	public Iterable<Bike> getAll() {
		return repo.findAll();
	}

	@Override
	//@Scheduled(cron = "0 15 10 25 * ?")
	public void updateStuas(int bikeid, String status) ////////////////////////////////////////////////////////////////////////////////trigger option//////////////////////////////////
	{

		System.out.println("BACK");
		Bike bike= repo.findOne(bikeid);
		bike.setRemark(status);

		repo.save(bike);


	}


	@Override
	public List<Bike> getAssetAuditData() {
		return repo.getAssetAuditData();
		
		
	}


	@Override
	public List<Bike> getRushi() {
		return repo.getRushi();
	}


	/*
	 * @Override public void addHistory(ArrayList<History> listhistory) { // TODO
	 * Auto-generated method stub
	 * 
	 * }
	 */

	/*
	 * @Override public void addHistory(History history) { return
	 * hrepo.save(history);
	 * 
	 * }
	 */
	
	/////////////////////////////////////////////////////////////////////////custom query




}







