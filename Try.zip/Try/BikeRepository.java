package com.Try;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface BikeRepository extends JpaRepository<Bike, Integer> 
{
    
	
	@Query(value = "SELECT * FROM tbl_try LIMIT 3 " ,nativeQuery = true)
    public List<Bike> getAssetAuditData();
	
	///we write hear custam Query
	
	
	@Query(value = "SELECT * FROM tbl_try LIMIT 2 " ,nativeQuery = true)
    public List<Bike> getRushi();




	//public Object save(ArrayList<History> listhistory);
	
	
}
////rushi
