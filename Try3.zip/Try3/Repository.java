package com.Try3;

public interface Repository {

	void save(History history);

}
