package com.Try3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class XLS 
 { 
	public static void main(String[] args) {
		
	
	    try
	    {
	    	System.out.println("start");
	    
	        FileInputStream myxls = new FileInputStream("D:\\abc.xlsx");
	        XSSFWorkbook studentsSheet = new XSSFWorkbook(myxls);
	        XSSFSheet worksheet = studentsSheet.getSheetAt(0);
	      

			
			//createRow(++lastRow);	int no ;
		

	        
	        int lastRow=worksheet.getLastRowNum();
	        System.out.println("mid");
	        System.out.println(lastRow);
	        System.out.println("------------------------------XLS-------------------------");

	        Row row = worksheet.createRow(++lastRow);
	        
	        row.createCell(0).setCellValue("adi");
	        row.createCell(1).setCellValue("rushi");
	        row.createCell(2).setCellValue("Pooja");
	        row.createCell(3).setCellValue("bro");
	        row.createCell(3).setCellValue("sweeti");

	        myxls.close();
	        FileOutputStream output_file =new FileOutputStream(new File("D:\\abc.xlsx"));  
	        studentsSheet.write(output_file);
	        output_file.close();
	        System.out.println(" is successfully written");
	        System.out.println("end");
			
	       
	     }
	     catch(Exception e)
	     {
	     }
	     	
			
	}
 }


