package com.Try3;

import javax.jdo.annotations.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Try.BikeRepository;
@Service


public class fileServiceImpl implements fileService {
@Autowired
Repository repo;
	
	
	@Override
	public void addHistory(History history) {
		repo.save(history);		

		
	}

	
	  
	 

}
